package com.rahmananda.crudrestoran;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudrestoran.Model.DataItem;
import com.rahmananda.crudrestoran.Model.ResponseRestoran;
import com.rahmananda.crudrestoran.Network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateDeleteActivity extends AppCompatActivity {

    @BindView(R.id.edt_update_nama)
    EditText edtUpdateNama;
    @BindView(R.id.edt_update_harga)
    EditText edtUpdateHarga;
    @BindView(R.id.edt_update_gambar)
    EditText edtUpdateGambar;
    @BindView(R.id.btn_update)
    Button btnUpdate;
    @BindView(R.id.btn_delete)
    Button btnDelete;

    DataItem dataitemMakanan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);
        ButterKnife.bind(this);

        dataitemMakanan = getIntent().getParcelableExtra("UPDATE");
            if (dataitemMakanan != null){
                edtUpdateNama.setText(dataitemMakanan.getMenuNama());
                edtUpdateHarga.setText(dataitemMakanan.getMenuHarga());
                edtUpdateGambar.setText(dataitemMakanan.getMenuGambar());
            }

        }

        @OnClick({R.id.btn_update, R.id.btn_delete})
        public void onViewClicked(View view) {
            switch (view.getId()) {
            case R.id.btn_update:

                String nama = edtUpdateNama.getText().toString();
                String harga = edtUpdateHarga.getText().toString();
                String gambar = edtUpdateGambar.getText().toString();

                if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(harga) || TextUtils.isEmpty(gambar)){
                    Toast.makeText(this, "Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }else {
                    actionUpdate(dataitemMakanan.getMenuId(),nama,harga,gambar);
                }

                break;
            case R.id.btn_delete:

                actionDelete(dataitemMakanan.getMenuId());

                break;
        }
    }

    private void actionUpdate(String id, String nama, String harga, String gambar){
        ApiClient.service.updateMakanan(id, nama, harga, gambar).enqueue(new Callback<ResponseRestoran>() {
            @Override
            public void onResponse(Call<ResponseRestoran> call, Response<ResponseRestoran> response) {
                if (response.isSuccessful()){
                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Toast.makeText(UpdateDeleteActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateDeleteActivity.this, pesan, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseRestoran> call, Throwable t) {

            }
        });
    }

    private void actionDelete (String id){
        ApiClient.service.deleteMakanan(id).enqueue(new Callback<ResponseRestoran>() {
            @Override
            public void onResponse(Call<ResponseRestoran> call, Response<ResponseRestoran> response) {
                if (response.isSuccessful()){
                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Toast.makeText(UpdateDeleteActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(UpdateDeleteActivity.this, pesan, Toast.LENGTH_SHORT).show();

                    }
                }
            }
            @Override
            public void onFailure(Call<ResponseRestoran> call, Throwable t) {

            }
        });
    }

}
