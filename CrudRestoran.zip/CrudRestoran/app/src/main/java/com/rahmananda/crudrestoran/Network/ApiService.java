package com.rahmananda.crudrestoran.Network;

import com.rahmananda.crudrestoran.Model.ResponseRestoran;
import com.rahmananda.crudrestoran.Model.login.ResponseLogin;
import com.rahmananda.crudrestoran.Model.register.ResponseRegister;

import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {

    @GET("Api/getMakanan")
    Call<ResponseRestoran> getAllMakanan();

    @FormUrlEncoded
    @POST("Api/insertMakanan")
    Call<ResponseRestoran> insertMakanan(@Field("name") String nama,
                                         @Field("price") String harga,
                                         @Field("gambar") String gambar);


    @FormUrlEncoded
    @POST("Api/updateMakanan")
    Call<ResponseRestoran> updateMakanan(@Field("id") String id,
                                         @Field("name") String name,
                                         @Field("price") String harga,
                                         @Field("gambar") String gambar);

    @FormUrlEncoded
    @POST("Api/deleteMakanan")
    Call<ResponseRestoran> deleteMakanan(@Field("id")String id);

    @FormUrlEncoded
    @POST("Api/login")
    Call<ResponseLogin> loginMakanan(@Field("email") String email,
                                     @Field("password") String password);

    @FormUrlEncoded
    @POST("Api/register")
    Call<ResponseRegister> registerMakanan (@Field("nama") String nama,
                                            @Field("email") String email,
                                            @Field("password") String password,
                                            @Field("nohp") String nohp);





}
