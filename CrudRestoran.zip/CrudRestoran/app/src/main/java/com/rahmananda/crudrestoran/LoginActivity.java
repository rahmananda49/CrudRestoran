package com.rahmananda.crudrestoran;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudrestoran.Model.ResponseRestoran;
import com.rahmananda.crudrestoran.Model.login.Data;
import com.rahmananda.crudrestoran.Model.login.ResponseLogin;
import com.rahmananda.crudrestoran.Network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.edt_username)
    EditText edtUsername;
    @BindView(R.id.edt_password)
    EditText edtPassword;
    @BindView(R.id.btn_login)
    Button btnLogin;
    @BindView(R.id.tv_register)
    TextView tvRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.btn_login, R.id.tv_register})
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.btn_login:

                String email = edtUsername.getText().toString();
                String pass = edtPassword.getText().toString();

                if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)){
                    Toast.makeText(this, "Inputan Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
                }else {
                    actionLogin(email,pass);
                }

                break;
            case R.id.tv_register:

                Intent intentRegister = new Intent(LoginActivity.this, com.rahmananda.crudrestoran.RegisterActivity.class);
                startActivity(intentRegister);

                break;
        }
    }

    private void actionLogin(String email, String password) {
        ApiClient.service.loginMakanan(email, password).enqueue(new Callback<ResponseLogin>() {
            @Override
            public void onResponse(Call<ResponseLogin> call, Response<ResponseLogin> response) {
                if (response.isSuccessful()) {


                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status) {
                        Data data = response.body().getData();


                        String email = data.getUserEmail();
                        String pass = data.getUserPassword();

                        com.rahmananda.crudlistmakanann.Preferences.actionLoginPreferences(LoginActivity.this, email, password);
                        Toast.makeText(LoginActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(LoginActivity.this , com.rahmananda.crudrestoran.MainActivity.class));
                        finish();
                    }else {
                        Toast.makeText(LoginActivity.this, pesan, Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onFailure(Call<ResponseLogin> call, Throwable t) {
                Toast.makeText(LoginActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });
    }
}
