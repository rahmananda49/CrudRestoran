package com.rahmananda.crudrestoran;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//import com.rahmananda.crudlistmakanann.model.login.Data;
//import com.rahmananda.crudlistmakanann.model.login.ResponseLogin;
//import com.rahmananda.crudlistmakanann.model.register.ResponseRegister;
//import com.rahmananda.crudlistmakanann.network.ApiClient;
import com.rahmananda.crudrestoran.Model.register.ResponseRegister;
import com.rahmananda.crudrestoran.Network.ApiClient;
import com.rahmananda.crudrestoran.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    @BindView(R.id.edt_nama)
    EditText edtNama;
    @BindView(R.id.edt_email)
    EditText edtEmail;
    @BindView(R.id.edt_password)
    EditText edtPassword;
    @BindView(R.id.edt_nohp)
    EditText edtNohp;
    @BindView(R.id.btn_register)
    Button btnRegister;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.btn_register})
    public void onViewClicked(View view) {

        String nama = edtNama.getText().toString();
        String email = edtEmail.getText().toString();
        String password = edtPassword.getText().toString();
        String nohp = edtNohp.getText().toString();

        if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(nohp)) {
            Toast.makeText(this, "Inputan Tidak Boleh Kosong", Toast.LENGTH_SHORT).show();
        } else {
            ApiClient.service.registerMakanan(nama, email, password, nohp).enqueue(new Callback<ResponseRegister>() {
                @Override
                public void onResponse(Call<ResponseRegister> call, Response<ResponseRegister> response) {
                    if (response.isSuccessful()) {
                        String pesan = response.body().getPesan();
                        boolean status = response.body().isSukses();
                        if (status) {
                            Toast.makeText(RegisterActivity.this, pesan, Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Toast.makeText(RegisterActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        }
                    }

                }

                @Override
                public void onFailure(Call<ResponseRegister> call, Throwable t) {
                    Toast.makeText(RegisterActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}