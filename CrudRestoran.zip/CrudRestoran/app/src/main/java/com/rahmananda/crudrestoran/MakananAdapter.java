package com.rahmananda.crudrestoran;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rahmananda.crudrestoran.Model.DataItem;

import java.util.List;

public class MakananAdapter extends RecyclerView.Adapter<MakananAdapter.MakananViewHolder> {

    List<DataItem> dataItems;
    Context context;

    public MakananAdapter(List<DataItem> listdata, Context datacontext){
        this.dataItems = listdata;
        this.context = datacontext;
    }

    @NonNull
    @Override
    public MakananAdapter.MakananViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_row_makanan,parent,false);
        return new MakananViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MakananAdapter.MakananViewHolder holder, int position) {
        holder.textName.setText(dataItems.get(position).getMenuNama());
        holder.textPrice.setText(dataItems.get(position).getMenuHarga());

        Glide.with(context).load(dataItems.get(position).getMenuGambar())
                .error(R.drawable.ic_launcher_background)
                .into(holder.imageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateDeleteActivity.class);
                intent.putExtra("UPDATE", dataItems.get(position));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataItems.size();
    }

    public class MakananViewHolder extends RecyclerView.ViewHolder {

        private ImageView imageView;
        private TextView textName, textPrice;

        public MakananViewHolder(@NonNull View itemView) {
            super(itemView);

            textName = itemView.findViewById(R.id.txt_name);
            textPrice = itemView.findViewById(R.id.txt_price);
            imageView = itemView.findViewById(R.id.img_gambar);
        }
    }
}
