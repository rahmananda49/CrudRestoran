package com.rahmananda.crudrestoran;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.rahmananda.crudrestoran.Model.ResponseRestoran;
import com.rahmananda.crudrestoran.Network.ApiClient;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InsertActivity extends AppCompatActivity {

    @BindView(R.id.edt_insert_nama)
    EditText edtInsertNama;
    @BindView(R.id.edt_insert_harga)
    EditText edtInsertHarga;
    @BindView(R.id.edt_insert_gambar)
    EditText edtInsertGambar;
    @BindView(R.id.btn_insert)
    Button btnInsert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btn_insert)
    public void onViewClicked() {

        String nama  = edtInsertNama.getText().toString();
        String harga  = edtInsertHarga.getText().toString();
        String gambar = edtInsertGambar.getText().toString();

        if (TextUtils.isEmpty(nama) || TextUtils.isEmpty(harga) || TextUtils.isEmpty(gambar)){
            Toast.makeText(this, "Tidak Boleh kosong", Toast.LENGTH_SHORT).show();
        }else {
            ApiClient.service.insertMakanan(nama,harga,gambar).enqueue(new Callback<ResponseRestoran>() {
                @Override
                public void onResponse(Call<ResponseRestoran> call, Response<ResponseRestoran> response) {
                    if (response.isSuccessful());

                    String pesan = response.body().getPesan();
                    boolean status = response.body().isSukses();

                    if (status){
                        Toast.makeText(InsertActivity.this, pesan, Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(InsertActivity.this, pesan, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseRestoran> call, Throwable t) {

                }
            });
        }

    }
}
